import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/root/zrail-rc9')
SNAP = Path('/mnt/volume_atl1_1787847588295/zrail-rc9/snapshots/rafter')
OUT = Path('/mnt/volume_atl1_1787847588295/zrail-rc9/evidence/rafter-public-api-baseline-20260907')
OUT.mkdir(exist_ok=False)
review = json.loads(Path('/tmp/rc9-rafter-public-api-review.json').read_text())
source = SNAP / review['path']


def run(command, **kwargs):
    return subprocess.check_output(command, text=True, **kwargs).strip()


status = ['git','-C',str(SNAP),'status','--porcelain=v1','--untracked-files=all']
assert not run(status)
assert run(['git','-C',str(SNAP),'rev-parse','HEAD']) == review['commit']
assert hashlib.sha256(source.read_bytes()).hexdigest() == review['sha256']
env = os.environ.copy()
env['CARGO_MANIFEST_DIR'] = str(SNAP / 'crates/rafter')
binary = OUT / 'legacy-public-api'
command = ['rustc','--edition=2024','--test',str(source),'-o',str(binary)]
subprocess.run(command,cwd=ROOT,env=env,check=True)
inventory = run([str(binary),'--list'])
names = [line.removesuffix(': test') for line in inventory.splitlines() if line.endswith(': test')]
assert len(names) == len(set(names)) == 8
assert sorted(names) == sorted(review['tests'])
log = OUT / 'legacy.log'
with log.open('wb') as stream:
    result = subprocess.run([str(binary),'--test-threads=2'],stdout=stream,stderr=subprocess.STDOUT)
outcomes = re.findall(r'^test (\S+) \.\.\. (\S+)$',log.read_text(),re.MULTILINE)
assert sorted(name for name,status in outcomes) == sorted(names)
assert not run(status)
receipt = dict(schema=1,repository=review['repository'],commit=review['commit'],
               tree=run(['git','-C',str(SNAP),'rev-parse','HEAD^{tree}']),source=review['path'],
               source_sha256=review['sha256'],command=command,
               environment={'CARGO_MANIFEST_DIR':env['CARGO_MANIFEST_DIR']},
               toolchain=run(['rustc','-Vv'],cwd=ROOT),tests=[dict(name=n,status=s) for n,s in outcomes],
               exit_code=result.returncode,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
               binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
               runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               limits='Unmodified frozen source-only guard baseline. No native parity, consumer build, simulation, Maelstrom execution or release qualification claim.')
(OUT / 'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
(OUT / 'runner.py').write_bytes(Path(__file__).read_bytes())
print('Frozen public API/docs guard:',len(outcomes),'outcomes; exit',result.returncode)
print('Evidence',OUT)
