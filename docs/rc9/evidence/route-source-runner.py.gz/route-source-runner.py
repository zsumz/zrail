import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/root/zrail-rc9')
BASE = Path('/mnt/volume_atl1_1787847588295/zrail-rc9')
OUT = BASE / 'evidence/route-source-parity-final-20260907'
OUT.mkdir(parents=True, exist_ok=False)
ENV = os.environ.copy()
ENV.update(CARGO_TARGET_DIR=str(BASE / 'target'), CARGO_BUILD_JOBS='2', CARGO_INCREMENTAL='0',
           CARGO_PROFILE_TEST_DEBUG='0', CARGO_PROFILE_DEV_DEBUG='0',
           TMPDIR=str(BASE / 'evidence'), PYTHONDONTWRITEBYTECODE='1',
           ZRAIL_RC9_SNAPSHOTS=str(BASE / 'snapshots'))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def inputs():
    diff = git('diff', '--binary', 'HEAD', '--')
    untracked = {}
    for raw in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0'):
        if not raw:
            continue
        path = raw.decode()
        file = ROOT / path
        payload = file.read_bytes()
        untracked[path] = dict(sha256=hashlib.sha256(payload).hexdigest(), bytes=len(payload), mode=oct(file.stat().st_mode & 0o777))
    return dict(commit=git('rev-parse','HEAD').decode().strip(),
                tree=git('rev-parse','HEAD^{tree}').decode().strip(),
                tracked_diff_sha256=hashlib.sha256(diff).hexdigest(), untracked=untracked,
                git_status=git('status','--porcelain=v1','--untracked-files=all').decode())


state = dict(schema=1, release_qualified=False, implementation=inputs(),
             runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             environment={key: ENV[key] for key in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL',
                 'CARGO_PROFILE_TEST_DEBUG','CARGO_PROFILE_DEV_DEBUG','TMPDIR','PYTHONDONTWRITEBYTECODE','ZRAIL_RC9_SNAPSHOTS']},
             started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), stages=[])
(OUT / 'tracked-changes.patch').write_bytes(git('diff','--binary','HEAD','--'))
(OUT / 'runner.py').write_bytes(Path(__file__).read_bytes())


def save():
    (OUT / 'runner.json').write_text(json.dumps(state,indent=2)+'\n')


save()
assert not state['implementation']['git_status'], 'qualify committed code'
stages = [
    (label, ['cargo','test','--locked','--offline','-p','zrail-rust','--lib',
             'qualify_frozen_route_source_and_compile_input_parity','--','--ignored','--nocapture'])
    for label in ['parity-a','parity-b']
]

for label, command in stages:
    ENV['ZRAIL_RC9_ROUTE_REPORT'] = str(OUT / (label+'.json'))
    print('Starting',label,flush=True)
    path = OUT / (label+'.log')
    with path.open('wb') as log:
        result = subprocess.run(command,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    payload = path.read_bytes()
    stage = dict(name=label,command=command,exit_code=result.returncode,log=path.name,
                 sha256=hashlib.sha256(payload).hexdigest(),bytes=len(payload))
    state['stages'].append(stage)
    state['inputs_unchanged'] = inputs()==state['implementation']
    save()
    print('Completed',label,'exit',result.returncode,'inputs unchanged',state['inputs_unchanged'],flush=True)
    if not state['inputs_unchanged']:
        raise RuntimeError('qualification inputs changed during execution')
    if result.returncode and (label != 'canonical' or not all(code.encode() in payload for code in
        ['LOCK-008','LOCK-016','LOCK-026','LOCK-028','LOCK-030'])):
        break
state['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print('Evidence',OUT,flush=True)

if len(state['stages']) == 2 and all(row['exit_code'] == 0 for row in state['stages']):
    first = (OUT/'parity-a.json').read_bytes()
    assert first == (OUT/'parity-b.json').read_bytes(), 'reports must repeat byte for byte'
    state['repeatability'] = dict(byte_identical=True, payload_bytes=len(first), payload_sha256=hashlib.sha256(first).hexdigest())
    save()
    print('Identical route reports:',state['repeatability'],flush=True)
